require 'rails_helper'

RSpec.describe "users/edit", type: :view do
  #before(:each) do
  #   @user = assign :user, User.create!(:name => 'asdf', :email => 'asdf@asdf.com', :password => 'asdf123')
  #end

  #it "renders the edit user form" do
  #  render

  #  assert_select "form[action=?][method=?]", params[:id], "post" do
      
  #  end
  #end
end
