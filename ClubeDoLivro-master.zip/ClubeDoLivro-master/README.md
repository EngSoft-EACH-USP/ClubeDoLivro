# ClubeDoLivro

[![Build Status](https://travis-ci.org/luispierro/ClubeDoLivro.png)](https://travis-ci.org/luispierro/ClubeDoLivro)
[![Code Climate](https://codeclimate.com/github/luispierro/ClubeDoLivro/badges/gpa.svg)](https://codeclimate.com/github/luispierro/ClubeDoLivro)
[![Issue Count](https://codeclimate.com/github/luispierro/ClubeDoLivro/badges/issue_count.svg)](https://codeclimate.com/github/luispierro/ClubeDoLivro)

EP de Engenharia

Heroku: https://clube-do-livro.herokuapp.com/
Pivotal Tracker: https://www.pivotaltracker.com/n/projects/1859031

Integrantes:

- Eduardo Kenji Matsuda (8516222)
- Heitor Vergilio Cord (7400902)
- Luis Felipe Maciel Pierro (8516500)
- Luiz Felipe Rosti Souza (8516073)
- Marcos Vinicius Mazzei (9004484)
- Rafael Gaspar de Sousa (8515944)

O ClubeDoLivro tem como intuito incentivar a leitura, voltada principalmente para os jovens. Tal incentivo se dá por um sistema no estilo e-commerce, que permite trocas de livros entre os usuários, bem como descrições e resenhas de acordo com suas preferências, construindo assim um perfil para recomendações.
